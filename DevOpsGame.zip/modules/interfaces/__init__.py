'''初始化'''
from .gameend import GameEndInterface
from .gamestart import GameStartInterface